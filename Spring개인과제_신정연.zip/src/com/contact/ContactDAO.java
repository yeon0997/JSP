package com.contact;

public class ContactDAO {

}
